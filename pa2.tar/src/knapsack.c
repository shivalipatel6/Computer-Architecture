#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct node{
  char name[32];
  int value;
  int weight;
}; // linked list :)


struct list{
  char name[32];
  int weight;
  struct list *next;
};// list of answers

struct list *front = NULL;// front of the list


int max(int num1, int num2){
     if(num1 > num2){
	return num1;
  }// num1 is bigger
     else{
	return num2;
}// num2 is bigger	

}// max function



void printmatrix(int **matrix, int limit, int maxitems){
	for(int i = 0; i<= limit; i++){
	int *rows = matrix[i];
	  for(int j = 0; j< maxitems; j++){
		if(j == (maxitems -1)){
		printf("%d", rows[j]);
		}// getting rid of pesky space prob
		else{
	        printf("%d ", rows[j]);
		}// if it isnt the last one
	  }// inner traversal
		printf("\n");
	}// outer traversal of matrix
return;
}// end print matrix

void fillmatrix( int **matrix, int limit, int maxitems, struct node *stuff){

   int *rows;
   int before;
   int colup;
   int mxvle;
   
   int *colrows;

   for(int i = 0; i<= limit; i++){

	rows = matrix[i];
      for( int j = 0; j < maxitems; j++){

	if(j == 0){
	before = 0;
	}//
	else{
	before = rows[j-1];
        }//end if else

	if(i == 0){
	colup =0;
	}// end if
	else{
	  if( i- stuff[j].weight < 1){
            colup = stuff[j].value;
	   }//
	   else{
	colrows = matrix[i-stuff[j].weight];
	     if(j-1 < 0){
		  colup = stuff[j].value;
	     }// no left column 
	   else{
	colup = colrows[j-1];
	colup = colup +stuff[j].value;
	}// end inner inner else
	}// end inner else

	}//else 

	if(stuff[j].weight > i){
	   mxvle = before;
	}// if the weight of curr is bigger than limit
	else{
	mxvle = max(before, colup);
	}// if the weight fits in
	rows[j] = mxvle;

	}// acessing each value of the table

  }// acessing the the rows of matrix


return;
}// end fill matrix!!!!!!!!!


struct list* finditems(int **matrix, int limit, int maxitems, struct node *stuff){
   int *rows;
    int i = limit;
 int j = maxitems-1;

    while(i > 0){
 //   printf("i = %d\n", i);
//	printf("j = %d\n",j);
	rows = matrix[i];
      while( j > 0){
//	printf("j = %d\n",j);

	if(rows[j] == rows[j-1]){
           j--;
	    continue;
	}// end if for equal values
	else if( rows[j] == 0){
	
	return front;
	}// end case where you have hit the end
	
struct list *temp;
	temp = (struct list *)malloc(sizeof(struct list)); 
	if(temp == NULL){
		printf("Stack is full\n");
		break; 
	}// end check case for insufficient memory

	strcpy(temp->name, stuff[j].name);
	temp->weight = stuff[j].weight;
	i = i -stuff[j].weight;
        temp->next = front;
	front = temp;
	j--;
	break;

      }// end inner for
if(j == 0 && i>0){
	if(rows[j] == 0){

	break;
	}//for zero case
else if(rows[j] >0){
struct list *temp;
	temp = (struct list *)malloc(sizeof(struct list)); 
	if(temp == NULL){
		printf("Stack is full\n");
		break; 
	}// end check case for insufficient memory
	strcpy(temp->name, stuff[j].name);
	temp->weight = stuff[j].weight;
	i = 0;
        temp->next = front;
	front = temp;
}// end inner if
}// end outer if

}// end outer for 


return front;
}// end finditems



void freeall(){
   struct list *temp1;

while(front != NULL){
   temp1 = front;
   front = front->next;
   free(temp1);
}// end while freeing loop


return;
}// end freeall for when the program terminates 



// start main!!!!!!!!!!!!!!!!!!!!!!!!!!!!
int main(int argc, char **argv) {
if(argc != 3){
  printf("error negative/or zero limit");
  exit(EXIT_FAILURE);
}// error negative/or zero limit

int maxitems;
int limit;
int r;
limit = atoi(argv[1]);
if(limit < 1){
  printf("error negative/or zero limit");
  exit(EXIT_FAILURE);
}// error negative/or zero limit
FILE* fp = fopen(argv[2], "r");
if (!fp){
exit(EXIT_FAILURE);
}// failure to open


r = fscanf(fp,"%d", &maxitems);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong

char nme[32];
int wght;
int vlue;

struct node *stuff = (struct node*)malloc(maxitems*sizeof(struct node));
if(!stuff){
exit(EXIT_FAILURE);
}// memory couldn't be allocated


for( int i =0; i< maxitems; i++){

       r = fscanf(fp, "%31s %d %d",nme,&wght,&vlue);
	if(r != 3){
	printf("scan prob2: %d",r);
	exit(EXIT_FAILURE);
	}// reader not reading case
	
	if(wght <= 0){
	printf("weight is less than or equal to zero");
	free(stuff);
	exit(EXIT_FAILURE);
	}// less than or equal to zero 

      if(vlue <= 0){
	printf("value is less than or equal to zero");
	free(stuff);
	exit(EXIT_FAILURE);
	}// less than or equal to zero 


	strcpy(stuff[i].name, nme);

	  stuff[i].weight = wght;
	  stuff[i].value = vlue;

}// populating linked list 



int limpuls = limit +1;
int **matrix = (int **)malloc(limpuls * sizeof(int*));
if(!matrix){
exit(EXIT_FAILURE);
}// memory couldn't be allocated

for( int i = 0; i<= limit; i++){
   matrix[i] = (int *)malloc( maxitems* sizeof(int));
	if(!matrix){
	exit(EXIT_FAILURE);
	}// memory couldn't be allocated

}// memory allocation for the columns

int *rows;
 
for(int i = 0; i<= limit; i++){

	rows = matrix[i];
      for( int j = 0; j < maxitems ; j++){
	rows[j] = 0;

	}// acessing each value of the table

  }// acessing the the rows of matrix


fillmatrix(matrix, limit, maxitems,stuff);

front = finditems(matrix, limit, maxitems,stuff);

int *row = matrix[limit];
int maxvalue = row[maxitems-1];
int totalweight = 0;
struct list *move;
move = front;
while(move != NULL){

printf("%s\n",move->name);
totalweight = totalweight + move->weight;
move = move->next;
}// end while for printing items
printf("%d / %d\n",maxvalue, totalweight);

//printmatrix(matrix, limit, maxitems);




// freeing the matrix!!!!!!!!
for( int i = 0; i<= limit; i++){
   free(matrix[i]);
}// memory allocation for the columns
free(matrix);
free(stuff);

freeall();
fclose(fp);
return EXIT_SUCCESS;
}//end main
