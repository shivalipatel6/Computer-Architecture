#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

struct node{
  char name[17];
  int index;
  struct node *next;
}; // linked list :)
struct node *head = NULL; // front of linked list
int insnbr = 0;
int out = 0;
int *outlist;
int arraysize = 0;

typedef enum{ AND, OR, NAND, NOR, XOR, NOT, PASS, DECODER, MULTIPLEXER} kind_t;

struct gate{
kind_t kind;
int size;
int *params;
struct gate *next;

};

struct circut{

struct gate *instruct;
int *inputs; // inputs for the chart that we print
int *outputs; // outputs for the chart that we print

}; // end circut
struct gate *first = NULL; // front of gate list

void insertGate(kind_t knd, int sze, int *array){

struct gate *temp = (struct gate*)malloc(sizeof(struct gate));
if(!temp){
exit(EXIT_FAILURE);
}// memory couldn't be allocated

temp->kind = knd;
temp->size = sze;
temp->params = array; 

temp->next = NULL;

if(first == NULL){
 first = temp;
  return;
}//end if


struct gate *pointer;
pointer = first;

while(pointer->next != NULL){
pointer = pointer->next;

}// end while loop

pointer->next = temp;

return;

}// end insertGate



int isEmpty() {
	if(head == NULL){
	return 1;
	} // returns 1 i.e. true value if no nodes in list
	else{
	return 0;
	}// if list is not empty returns 0 i.e. false

}// end is empty function ; is there to check if there is still nodes in list


void insert( int indx, char *nme){

struct node *stuff = (struct node*)malloc(sizeof(struct node));
if(!stuff){
exit(EXIT_FAILURE);
}// memory couldn't be allocated

strcpy(stuff->name, nme);
stuff->index = indx;
arraysize = indx;
stuff->next = NULL;

if(head == NULL){
 head = stuff;
  return;
}//end if


struct node *traversal;
traversal = head;

while(traversal->next != NULL){
traversal = traversal->next;

}// end while loop

traversal->next = stuff;


return;
}// end insert

int checkVariables(char *nme){

if(strcmp(nme, "0") == 0){
return 0;
}// if we find a match

if(strcmp(nme, "1") == 0){
return 1;
}// if we find a match

struct node *traversal;
traversal = head;

while(traversal->next != NULL){

if(strcmp(nme, traversal->name) == 0){

return traversal->index;
}// if we find a match

traversal = traversal->next;

}// end while loop

if(strcmp(nme, traversal->name) == 0){

return traversal->index;
}// if we find a match

int newindx = traversal->index +1;
if(arraysize < newindx){
arraysize = newindx;
}// end if 
insert(newindx, nme);

return newindx;


}// end checkVariables


int* runthroughcircuts(int *inputs){

int *varlist = (int *)malloc((arraysize +1)* sizeof(int));
for(int i = 0; i < (arraysize +1); i++){
varlist[i] = 0;
}// end for loop

varlist[0] = 0;
varlist[1] = 1;
  for(int i = 0; i< (insnbr ); i++){
     varlist[i +2] = inputs[(insnbr-1)-i]; 
  }// end for loop
struct gate *pointer;
pointer = first;
//printf("start evaluation\n");
while(pointer != NULL){

/*for(int i = 0; i < (arraysize +1); i++){
printf("%d", varlist[i]);
}// end for loop
printf("\n"); */

if(pointer->kind == AND){

varlist[pointer->params[2]] = varlist[pointer->params[1]] && varlist[pointer->params[0]];

}// end AND gate
else if(pointer->kind == OR){

varlist[pointer->params[2]] = varlist[pointer->params[1]] || varlist[pointer->params[0]];

}// end OR gate
if(pointer->kind == NAND){

varlist[pointer->params[2]] = !(varlist[pointer->params[1]] && varlist[pointer->params[0]]);

}// end NAND gate
if(pointer->kind == NOR){

varlist[pointer->params[2]] = !(varlist[pointer->params[1]] || varlist[pointer->params[0]]);

}// end NOR gate
if(pointer->kind == XOR){

varlist[pointer->params[2]] = (varlist[pointer->params[1]] ^ varlist[pointer->params[0]]);

}// end XOR gate
if(pointer->kind == NOT){


varlist[pointer->params[1]] = !(varlist[pointer->params[0]] );

}// end NOT gate
if(pointer->kind == PASS){

varlist[pointer->params[1]] = varlist[pointer->params[0]];

}// end PASS gate
if(pointer->kind == DECODER){

int *decodeIn = (int *)malloc((pointer->size)* sizeof(int));
int i = 0;
for(i = 0; i< pointer->size; i++){
     decodeIn[i]= pointer->params[i];

}// end for loop
int *decodeOut = (int *)malloc(((1<<pointer->size))* sizeof(int));
for(int j = 0; j < (1<<pointer->size); j++){
 decodeOut[j] = pointer->params[i];
 i++;
}// end for loop

int index =0;
for(int i = 0; i<(1<< pointer->size); i++){

  varlist[decodeOut[i]] = 0;

}// end for loop

for(int i =0; i< pointer->size; i++){
  index += varlist[decodeIn[i]] *((1<<(pointer->size -i-1)));

}// end for loop
  varlist[decodeOut[index]] = 1;
  
free(decodeOut);
free(decodeIn);
}// end DECODER gate
if(pointer->kind == MULTIPLEXER){
int *selectors = (int *)malloc(((1<<pointer->size))* sizeof(int));
int *multiIN = (int *)malloc((pointer->size)* sizeof(int));
int j = 0;
for( j = 0; j < (1<<pointer->size); j++){
 selectors[j] = pointer->params[j];

}// end for loop

for(int i = 0; i< pointer->size; i++){
     multiIN[i]= pointer->params[j];
j++;
}// end for loop
int multiout = pointer->params[j];

int s =0;
int k;
for(k=0; k< pointer->size; k++){

 s+= varlist[multiIN[k]]*(1<< (pointer->size - k -1));
}// end for

varlist[multiout] = varlist[selectors[s]];
free(selectors);
free(multiIN);
}// end MULTIPLEXER gate
pointer = pointer->next;

}// end while loop

int *temp = (int *)malloc(out * sizeof(int));
outlist = temp ;
int j = 0;
for( int i = (insnbr +2); i < (insnbr + out +2); i++){

   temp[j] = varlist[i];
  j++;
}// end for loop for making output list
//printf("end evaluation\n");
free(varlist);
return outlist;
}// end runthroughcircuts

void printall(){

if(head == NULL){
 printf("0\n");
  return;
}//end if

struct node *traversal;
traversal = head;

while(traversal->next != NULL){
printf("%s %d\n", traversal->name, traversal->index);
traversal = traversal->next;

}// end while loop
printf("%s %d\n", traversal->name, traversal->index);

return;
}//end printall

void freegates(){
struct gate *temp;

while(first != NULL){
free(first->params);
temp = first;
first = first->next;
free(temp);
}// end freeing while
return;
}// end freegates


void freeall(){
   struct node *temp;
   
   while(isEmpty() == 0){
   temp = head;
   head = head->next;
   free(temp);
}// end while freeing loop
return;
}// end freeall for when the program terminates because of



int main(int argc, char **argv) {

if(argc !=2){
  exit(EXIT_FAILURE);
}// error negative/or zero limit

FILE* fp = fopen(argv[1], "r");
if (!fp){
exit(EXIT_FAILURE);
}// failure to open

int r;
char ins[17]= "";


struct circut *crct = (struct circut*)malloc(sizeof(struct circut));
crct->instruct = first;

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong


r = fscanf(fp,"%d", &insnbr);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong 

int *temparry = (int *)malloc( insnbr* sizeof(int));
crct->inputs = temparry;

for(int i =0; i< insnbr; i++){
int inputnbr = i +2;
r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong

insert(inputnbr, ins);

}// end for loop

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong

r = fscanf(fp,"%d", &out);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong

//int *temparrys = (int *)malloc(out* sizeof(int));
//crct->outputs = temparrys;

for(int i =0; i< out; i++){

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong

int idx = i + insnbr +2;
insert(idx, ins);

}// end for loop




//printf(" making the gates!!!\n");
// start making the gates here!!!!!!!!11



while(fscanf(fp,"%s",ins) ==1){
//printf("entered the while loop\n");

char directives[17]= "";
//r = fscanf(fp,"%s",ins);
if(r != 1){
printf("error babes ; )");
exit(EXIT_FAILURE);
}// read went wrong

if(strcmp(ins, "AND") == 0){
int *vars = (int *)malloc( 3* sizeof(int));
if(!vars){
exit(EXIT_FAILURE);
}// memory couldn't be allocated

kind_t type = AND;
strcpy(directives, ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[0] = checkVariables(ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[1] = checkVariables(ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[2] = checkVariables(ins);
insertGate(type, 3, vars);

}// if else for AND
else if (strcmp(ins, "OR") == 0){

int *vars = (int *)malloc( 3* sizeof(int));
if(!vars){
exit(EXIT_FAILURE);
}// memory couldn't be allocated
kind_t type = OR;
strcpy(directives, ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[0] = checkVariables(ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[1] = checkVariables(ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[2] = checkVariables(ins);
insertGate(type, 3, vars);
}// if else for OR
else if (strcmp(ins, "NAND") == 0){

int *vars = (int *)malloc( 3* sizeof(int));
if(!vars){
exit(EXIT_FAILURE);
}// memory couldn't be allocated
kind_t type = NAND;
strcpy(directives, ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[0] = checkVariables(ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[1] = checkVariables(ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[2] = checkVariables(ins);
insertGate(type, 3, vars);
}// if else for NAND
else if (strcmp(ins, "NOR") == 0){

int *vars = (int *)malloc( 3* sizeof(int));
if(!vars){
exit(EXIT_FAILURE);
}// memory couldn't be allocated
kind_t type = NOR;
strcpy(directives, ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[0] = checkVariables(ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[1] = checkVariables(ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[2] = checkVariables(ins);
insertGate(type, 3, vars);
}// if else for NOR
else if (strcmp(ins, "XOR") == 0){

int *vars = (int *)malloc( 3* sizeof(int));
if(!vars){
exit(EXIT_FAILURE);
}// memory couldn't be allocated
kind_t type = XOR;
strcpy(directives, ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[0] = checkVariables(ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[1] = checkVariables(ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[2] = checkVariables(ins);
insertGate(type, 3, vars);
}// if else for XOR
else if (strcmp(ins, "NOT") == 0){

int *vars = (int *)malloc( 2* sizeof(int));
if(!vars){
exit(EXIT_FAILURE);
}// memory couldn't be allocated
kind_t type = NOT;
strcpy(directives, ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[0] = checkVariables(ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[1] = checkVariables(ins);

insertGate(type, 2, vars);
}// if else for NOT
else if (strcmp(ins, "PASS") == 0){

int *vars = (int *)malloc( 2* sizeof(int));
if(!vars){
exit(EXIT_FAILURE);
}// memory couldn't be allocated
kind_t type = PASS;
strcpy(directives, ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[0] = checkVariables(ins);

r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[1] = checkVariables(ins);

insertGate(type, 2, vars);
}// if else for PASS
else if (strcmp(ins, "DECODER") == 0){
//printf("enter decoder\n");
r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
int decodersize = atoi(ins);
int darraysize = decodersize + (1<<decodersize);
int *vars = (int *)malloc( darraysize* sizeof(int));
if(!vars){
exit(EXIT_FAILURE);
}// memory couldn't be allocated
kind_t type = DECODER;

for(int i = 0; i < darraysize; i++){
r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[i] = checkVariables(ins);
}// end for loop

insertGate(type, decodersize, vars);
}// if else for DECODER
else if (strcmp(ins, "MULTIPLEXER") == 0){
r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
int multiplexersize = atoi(ins);
int marraysize = multiplexersize + (1<<multiplexersize) +1;
int *vars = (int *)malloc( marraysize* sizeof(int));
if(!vars){
exit(EXIT_FAILURE);
}// memory couldn't be allocated
kind_t type = MULTIPLEXER;

for(int i = 0; i < marraysize; i++){
r = fscanf(fp,"%s",ins);
if(r != 1){
exit(EXIT_FAILURE);
}// read went wrong
vars[i] = checkVariables(ins);
}// end for loop

insertGate(type, multiplexersize, vars);

}// if else for MULTIPLEXER

}// end do while loop

//printall();
//printf("%d\n",arraysize);

int oneOrzero = -1;
for( int i = 0; i <(1<< insnbr); i++){

    for(int j = insnbr-1; j>=0; j--){
	oneOrzero = (i/(1<<j)) % 2;
	crct->inputs[j% insnbr] = oneOrzero;
	printf("%d ", crct->inputs[j% insnbr]); 	

}// end inner for loop
printf("|");
 crct->outputs = runthroughcircuts(crct->inputs);
for(int i = 0; i < out; i++){

printf(" %d", crct->outputs[i]); 

}//end for loop
printf("\n");
free(outlist);
}// end outer for loop

//printall();
freegates();
free(crct->inputs);

free(crct);
freeall();
fclose(fp);
return EXIT_SUCCESS;
}// end main
